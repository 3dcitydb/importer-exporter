﻿About
--------
Digital 3D buildings of the main campus of Technische Universität München
(TUM), Germany, and surrounding blocks in Level of Detail (LoD) 2. 
The buildings were automatically generated from the land register map
and 3D point clouds using a special 3D reconstruction software.


Copyright
------------
This test data is provided by the Bavarian Administration for Surveying 
under the licence © CC BY-NC-ND (Attribution, NonCommercial, NonDerivatives,
see https://creativecommons.org/licenses/by-nc-nd/4.0/ )


Website
-----------
http://www.geodaten.bayern.de
