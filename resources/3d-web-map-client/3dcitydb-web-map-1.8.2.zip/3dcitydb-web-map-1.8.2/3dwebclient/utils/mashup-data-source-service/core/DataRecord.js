var DataRecord = /** @class */ (function () {
    function DataRecord() {
    }
    return DataRecord;
}());
